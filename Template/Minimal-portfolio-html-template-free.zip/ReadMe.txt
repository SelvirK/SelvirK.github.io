Miniml is a fully Responsive Portfolio template built with Bootstrap 3 and HTML & CSS.

It is very easy to use & edit and for Creative Professionals Business & Startup and Freelancers who are looking to display their portfolios in a great modern way.

Main Features

� 5 HTML Pages
� Fully Responsive
� Masonry Portfolio
� Bootstrap 3.3.6
� HTML5 & CSS3
� Working Contact Form
� Well Documented Code